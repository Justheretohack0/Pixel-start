// This component is no longer used in the standalone version.
import React from 'react';

export const ExtensionTutorial: React.FC<any> = () => {
    return null;
};
